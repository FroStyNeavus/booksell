<?php
if (ISSET($_REQUEST["global_message"]))
    $msg = "<span class=\"warningMessage\">" . $_REQUEST["global_message"] . "</span>";
$u = "";
if (ISSET($_REQUEST["username"]))
    $u = $_REQUEST["username"];
?>
<header class="masthead" id="Ajouter">
    <!-- This snippet uses Font Awesome 5 Free as a dependency. You can download it at fontawesome.io! -->
    <div id="loginForm">
        <div class="container">
            <div class="row">
                <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                    <div class="card card-signin my-5">
                        <div class="card-body">
                            <h3 id="erreurAjouter" hidden="" class="text-center mt-0" style="color: red">L'ouvrage a ete
                                supprimer !!</h3>
                            <h3 id="succesAjouter" hidden="" class="text-center mt-0" style="color: lawngreen">L'ouvrage
                                a ete modifier !!</h3>
                            <h5 class="card-title text-center">Ajouter une oeuvre</h5>
                            <form name="myForm" onsubmit="return validateForm()">
                                <label for="nom">Nom de l'oeuvre</label>
                                <input type="text" id="nom" name="nom" class="form-control" placeholder="Nom" required
                                       autofocus>

                                <label for="auteur">Auteur</label>
                                <input pattern= "[A-Z]" type="text" id="auteur" name="auteur" class="form-control" placeholder="Auteur"
                                       required autofocus>

                                <label for="editeur">Editeur</label>
                                <input type="text" id="editeur" name="editeur" class="form-control"
                                       placeholder="Editeur" required autofocus>

                                <label for="matiere">Matiere</label>
                                <input pattern= "[A-Z]" type="text" id="matiere" name="matiere" class="form-control"
                                       placeholder="Matiere" required autofocus>

                                <label for="image">Image</label>
                                <input type="text" id="image" name="image" class="form-control"
                                       placeholder="Liens direct vers l'image" required autofocus>

                                <label for="id">Prix</label>
                                <input pattern= "[0-9]" type="number" id="prix" name="prix" class="form-control" placeholder="Prix"
                                       required autofocus>
                                <br>
                                <button class="btn btn-lg btn-primary btn-block text-uppercase"
                                        onclick="addSomething(getElementById('nom').value, getElementById('auteur').value, getElementById('editeur').value, getElementById('matiere').value, getElementById('prix').value, getElementById('image').value)"
                                        type="submit">Modifier
                                </button>
                            </form>

                                <hr class="my-4">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
