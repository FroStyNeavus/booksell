<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light fixed-top py-3 navbar-scrolled"  id="mainNav">

    <!-- Navbar brand -->
    <!-- Le nom du site changer -->
    <a class="text-dark navbar-brand js-scroll-trigger" href="#page-top">Textbook</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
            data-target="#navbarResponsive">
        <div class="navbar-toggler-icon"></div>
    </button>

    <!-- Contenue effondrable -->
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <!-- Menu -->
        <ul class="text-dark navbar-nav ml-auto my-2 my-lg-0">
            <li class="nav-item">
                <a class="text-dark nav-link js-scroll-trigger" href="?action=accueil">Accueil</a>
            </li>
            <li class="nav-item">
                <a class="text-dark nav-link js-scroll-trigger" href="?action=apropos">À propos</a>
            </li>
            <li class="nav-item">
                <a class="text-dark nav-link js-scroll-trigger" href="?action=contact">Contact</a>
            </li>
            <?php
            if (!ISSET($_SESSION)) session_start();
            if (ISSET($_SESSION["connected"])) {
                ?>
                <li class="nav-item">
                    <a class="text-dark nav-link js-scroll-trigger" href="?action=ajouter">Ajouter une oeuvre</a>
                </li>
                <li class="nav-item">
                    <a class="text-dark nav-link js-scroll-trigger" href="?action=catalogue">Catalogue</a>
                </li>
                <li class="nav-item"><a class="text-dark nav-link js-scroll-trigger" href="?action=logout">Se
                        déconnecter (<?= $_SESSION["connected"] ?>)</a></li>
                <?php
            } else {
                ?>
                <li class="nav-item">
                    <a class="text-dark nav-link js-scroll-trigger" href="?action=login">Se connecter</a>
                </li>
                <li class="nav-item">
                    <a class="text-dark nav-link js-scroll-trigger" href="?action=inscription">S'inscrire</a>
                </li>
                <?php
            }
            ?>
        </ul>
        <!-- Formulaire de recherche -->
        <form action="?action=recherche" method="post" class="form-inline ml-auto my-2 my-lg-0">
            <div class="md-form my-lg-0 my-2">
                <input name="lname" class="form-control" type="text" placeholder="Rechercher un manuel"
                       aria-label="Search">
            </div>
            <button class="btn btn-primary btn-md my-0 ml-sm-2" type="submit">Search</button>
        </form>
    </div>
</nav>
