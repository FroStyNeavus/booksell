<!-- Header principal -->
<header class="masthead">
    <div class="container h-100">
        <div class="row h-100 align-items-center justify-content-center text-center">
            <div class="col-lg-10 align-self-end">
                <h1 class="text-uppercase text-white font-weight-bold">Le meilleur endroit pour acheter vos manuels
                    scolaires</h1>
                <hr class="divider my-4">
            </div>
            <div class="col-lg-8 align-self-baseline">
                <p class="text-white-75 font-weight-light mb-5">Textbook vous permet d'acheter vos manuels scolaires
                    moins chers et de les revendre quand vous n'en
                    avez plus besoins!</p>
                <a class="btn btn-primary btn-xl js-scroll-trigger" href="?action=contact">En savoir plus</a>
            </div>
        </div>
    </div>
</header>

<section class="page-section" id="populaires">
    <div class="container">
        <h2 class="text-center mt-0">Les ouverages les plus populaires</h2>
        <hr class="divider my-4">
        <div class="row">
            <div class="col-lg-3 cold-md-6 text-center">
                <a class="text-dark" href="#">
                    <div class="mt-5">
                        <img class="livre" src="./img/portfolio/livres/1.jpg">
                        <h3 class="h4 mb-2">Stewart - Calcul différentiel</h3>
                        <p class="text-muted mb-0">James Stewart</p>
                    </div>
                </a>
            </div>
            <div class="col-lg-3 cold-md-6 text-center">
                <a class="text-dark" href="#">
                    <div class="mt-5">
                        <img class="livre" src="./img/portfolio/livres/2.jpg">
                        <h3 class="h4 mb-2">Physique méchanique - Tome XXI</h3>
                        <p class="text-muted mb-0">Marc Séguin</p>
                    </div>
                </a>
            </div>
            <div class="col-lg-3 cold-md-6 text-center">
                <a class="text-dark" href="#">
                    <div class="mt-5">
                        <img class="livre" src="./img/portfolio/livres/3.jpg">
                        <h3 class="h4 mb-2">Chimie générale - 4e édition</h3>
                        <p class="text-muted mb-0">Raymond Chang</p>
                    </div>
                </a>
            </div>
            <div class="col-lg-3 cold-md-6 text-center">
                <a class="text-dark" href="#">
                    <div class="mt-5">
                        <img class="livre" src="./img/portfolio/livres/4.jpg">
                        <h3 class="h4 mb-2">Candide - Édition Magnard</h3>
                        <p class="text-muted mb-0">Voltaire</p>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>

<section id="categories">
    <div class="container-fluid p-0">
        <div class="row no-gutters">
            <div class="col-lg-4 col-sm-6">
                <a class="categories-box" href="#">
                    <img class="img-fluid" src="./img/portfolio/categories/1.jpg" alt="Mathématiques">
                    <div class="categories-box-caption">
                        <div class="project-category text-white-50">
                            Catégorie
                        </div>
                        <div class="project-name">
                            Mathématiques
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a class="categories-box" href="#">
                    <img class="img-fluid" src="./img/portfolio/categories/2.jpg" alt="Physique">
                    <div class="categories-box-caption">
                        <div class="project-category text-white-50">
                            Catégorie
                        </div>
                        <div class="project-name">
                            Physique
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a class="categories-box" href="#">
                    <img class="img-fluid" src="./img/portfolio/categories/3.jpg" alt="Chimie">
                    <div class="categories-box-caption">
                        <div class="project-category text-white-50">
                            Catégorie
                        </div>
                        <div class="project-name">
                            Chimie
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a class="categories-box" href="#">
                    <img class="img-fluid" src="img/portfolio/categories/4.jpg" alt="Français">
                    <div class="categories-box-caption">
                        <div class="project-category text-white-50">
                            Catégorie
                        </div>
                        <div class="project-name">
                            Français
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a class="categories-box" href="#">
                    <img class="img-fluid" src="./img/portfolio/categories/5.jpg" alt="Philosophie">
                    <div class="categories-box-caption">
                        <div class="project-category text-white-50">
                            Catégorie
                        </div>
                        <div class="project-name">
                            Philosophie
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4 col-sm-6">
                <a class="categories-box" href="#">
                    <img class="img-fluid" src="./img/portfolio/categories/6.jpg" alt="Anglais">
                    <div class="categories-box-caption">
                        <div class="project-category text-white-50">
                            Catégorie
                        </div>
                        <div class="project-name">
                            Anglais
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>

<section class="page-section bg-dark text-white">
    <div class="container text-center">
        <h2 class="mb-4">Explorez plus de catégories!</h2>
        <a class="btn btn-light btn-xl" href="#">Explorez maintenant!</a>
    </div>
</section>