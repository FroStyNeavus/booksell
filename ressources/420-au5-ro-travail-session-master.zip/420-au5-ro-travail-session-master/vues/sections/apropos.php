<section class="page-section" >
    <div id="container">
        <div class="mt-5">
            <h1 class="font-weight-bold text-center mt-0 mt-lg-0 text-uppercase">Nos fondateurs</h1>
            <hr class="divider my-4">
        </div>
        <div class="row align-items-center justify-content-center">
            <div class="col-lg-3 cold-md-6 text-center border-right-0 border-primary border rounded">
                <div class="mt-5">
                    <img src="./img/fondateurs/ilyass.jpg" class="rounded-circle border border-primary"/>
                    <div class="mt-5">
                        <h2>Ilyass El Ouazzani</h2>
                        <p class="mt-5">Ilyass El Ouazzani est un étudiant du collège de Rosemont. Il est en cheminement pour terminer sa technique
                            en informatique de gestion. Il est le co-fondateur de ce merveilleux site web.</p>
                        <a class="mb-5 mt-5 btn btn-primary btn-xl js-scroll-trigger" href="#">Voir le C.V.</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 cold-md-6 text-center border border-primary rounded">
                <div class="mt-5">
                    <img src="./img/fondateurs/dany.jpg" class="rounded-circle border border-primary"/>
                    <div class="mt-5">
                        <h2>Dany Galarneau</h2>
                        <p class="mt-5">Dany Galarneau est un étudiant du collège de Rosemont. Il est en cheminement pour terminer sa technique
                            en informatique de gestion. Il est le co-fondateur de ce merveilleux site web.</p>
                        <a class="mb-5 mt-5 btn btn-primary btn-xl js-scroll-trigger" href="static/cv_Dany_Galarneau.html">Voir le C.V.</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 cold-md-6 text-center border-left-0 border-primary border rounded">
                <div class="mt-5">
                    <img src="./img/fondateurs/eliot.jpg" class="rounded-circle border border-primary"/>
                    <div class="mt-5">
                        <h2>Eliot Dimitri Djoumessi</h2>
                        <p class="mt-5">Eliot Dimitri Djoumessi est un étudiant du collège de Rosemont. Il est en cheminement pour terminer sa technique
                            en informatique de gestion. Il est le co-fondateur de ce merveilleux site web.</p>
                        <a class="mb-5 mt-5 btn btn-primary btn-xl js-scroll-trigger" href="static/cv_eliot.html">Voir le C.V.</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="liens">
    <div class="container">
        <div class="row align-items-center justify-content-center text-center">
            <div class="col-lg-8 text-center">
                <h2 class="text-white mt-0">Lien vers les C.V.</h2>
            </div>
        </div>

    </div>
    </div>
</section>