<!DOCTYPE html>
<html>
	<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Le nom du site changer -->
        <title>Textbook - Acheter vos manuels scolaires</title>

        <!-- Font : Awesome Icons -->
        <link href="./js/fontawesome-free/css/all.min.css" rel="stylesheet">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet"
              type="text/css">

        <!-- Plugin CSS -->
        <link href="./js/magnific-popup/magnific-popup.css" rel="stylesheet">

        <!-- CSS avec bootstrap -->
        <link href="./css/creative.min.css" rel="stylesheet">

        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js">
        <link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
        <link rel="stylesheet" type="text/css" href="./css/connectionstyle.css">
	</head>

	<body id="page-top">
    <?php
    include("navbar.php");
    ?>
	<div>
		<main id="content">
			<?php echo $contenu; ?>
		</main>
	<?php
		include("footer.php");
	?>
	</div>
    <!-- Bootstrap core JavaScript -->
    <script src="./js/jquery/jquery.min.js"></script>
    <script src="./js/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="./js/jquery-easing/jquery.easing.min.js"></script>
    <script src="./js/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="./js/creative.min.js"></script>
    <script src="./js/ajax.js"></script>
    <script src="./js/framework.js"></script>
    <script src="./js/gestion_produits.js"></script>
	</body>
</html>