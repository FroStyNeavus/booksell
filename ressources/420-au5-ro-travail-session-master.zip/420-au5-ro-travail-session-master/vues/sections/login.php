<?php
	if (ISSET($_REQUEST["global_message"]))
	   $msg="<span class=\"warningMessage\">".$_REQUEST["global_message"]."</span>";
	$u = "";
	if (ISSET($_REQUEST["username"]))
		$u = $_REQUEST["username"];
?>	
    <header class="masthead" id="Se connecter">
        <!-- This snippet uses Font Awesome 5 Free as a dependency. You can download it at fontawesome.io! -->
        <div id="loginForm">
        <div class="container">
            <div class="row">
                <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                    <div class="card card-signin my-5">
                        <div class="card-body">
                            <h5 class="card-title text-center">Connection</h5>
                            <form class="form-signin" method="post">

                                <div class="form-label-group">
                                    <input type="text" id="username" name="username" class="form-control" placeholder="Username" required autofocus>
                                    <label for="username">Username</label>
                                    <?php if (ISSET($_REQUEST["field_messages"]["username"]))
                                        echo "<br /><span class=\"warningMessage\">".$_REQUEST["field_messages"]["username"]."</span>";
                                    ?>
                                </div>

                                <div class="form-label-group">
                                    <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
                                    <label for="password">Mots de passe</label>
                                    <?php if (ISSET($_REQUEST["field_messages"]["password"]))
                                        echo "<br /><span class=\"warningMessage\">".$_REQUEST["field_messages"]["password"]."</span>";
                                    ?>
                                </div>

                                <div class="custom-control custom-checkbox mb-3">
                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                    <label class="custom-control-label" for="customCheck1">Remember password</label>
                                </div>
                                <button class="btn btn-lg btn-primary btn-block text-uppercase" value=" OK " type="submit">Connection</button>

                                <button class="btn btn-lg btn-primary btn-block text-uppercase" onclick="window.location.href = 'inscription.html';">Creer un compte</button>

                                <hr class="my-4">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
    </header>




