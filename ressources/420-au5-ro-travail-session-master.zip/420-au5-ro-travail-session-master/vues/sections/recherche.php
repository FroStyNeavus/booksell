<h2 class="center ">Liste des livres</h2>
<?php

echo "<table id='listeProd'>";
$p = $data;
if ($p != null) {
    ?>

    <div class="container " align="center">
        <div class="col-lg-4 col-sm-6">
            <div class="product-card">
                <div class="product-grid-content">
                    <div class="product-header">
                        <a class="author">
                            <br><br><br>
                            <?php
                            echo $p->getAuteur();
                            ?>
                        </a>
                        <br>
                        <a>
                            <?php
                            echo $p->getNom();
                            ?>
                        </a>
                    </div>
                    <div class="product-card--body">
                        <div class="card-image">
                            <img src=<?php echo $p->getImage(); ?> alt="">
                        </div>
                        <div class="price-block">
                            <?php
                            echo $p->getPrix(), "$";
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
} else {
    ?>
    <br><br><br><br>
    <div class="container " align="center">
        <?php
        $nom = $_POST['lname'];
        echo "Aucun livre nommé '$nom' n'a été trouvé.";
        ?>
    </div>
    <?php
}
?>
