<!-- Header principal -->
<header class="masthead" id="S'inscrire">
    <!-- This snippet uses Font Awesome 5 Free as a dependency. You can download it at fontawesome.io! -->


    <div class="container">
        <div class="row">
            <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                <div class="card card-signin my-5">
                    <div class="card-body">
                        <h5 class="card-title text-center">Inscription</h5>
                        <form class="form-signin" method="post">


                            <div class="form-label-group">
                                <input type="text" id="inputUsername" name="username" class="form-control" placeholder="Username" required autofocus>
                                <label for="inputUsername">Username</label>
                                <?php if (ISSET($_REQUEST["field_messages"]["username"]))
                                    echo "<br /><span class=\"warningMessage\">".$_REQUEST["field_messages"]["username"]."</span>";
                                ?>
                            </div>

                            <div class="form-label-group">
                                <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email address" required autofocus>
                                <label for="inputEmail">Adresse Courriel</label>
                            </div>

                            <div class="form-label-group">
                                <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
                                <label for="inputPassword">Mots de passe</label>
                            </div>

                            <button class="btn btn-lg btn-primary btn-block text-uppercase" value=" OK " type="submit">S'inscrire</button>

                            <button class="btn btn-lg btn-primary btn-block text-uppercase" href="?action=login">Se connecter</button>

                            <hr class="my-4">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

