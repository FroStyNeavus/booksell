<section class="page-section" id="populaires">
    <div class="container" align="center">
        <h2 class="text-center mt-0">Listes des ouvrages</h2>
        <br>
        <br>
        <h3 id="supprimerHeader" hidden="" class="text-center mt-0" style="color: red">L'ouvrage a ete supprimer !!</h3>
        <h3 id="modifierHeader" hidden="" class="text-center mt-0" style="color: red">L'ouvrage a ete modifier !!</h3>
        <hr class="divider my-4">

        <div class="shop-product-wrap grid with-pagination row space-db--30 shop-border">
            <?php

            echo "<table id='listeProd'>";
            while ($data->next())
            {
            $p = $data->current();
            if ($p != null)
            {
            ?>
            <div class="col-lg-4 col-sm-6" style="border-style: solid;border-color: orange;border-width: medium;">
                <div class="product-card">
                    <div class="product-grid-content">
                        <div class="product-header">
                            <a class="author">
                                <?php
                                echo $p->getAuteur();
                                ?>
                            </a>
                            <br>
                            <a>
                                <?php
                                echo $p->getNom();
                                ?>
                            </a>
                        </div>
                        <div class="product-card--body">
                            <div class="card-image">
                                <img style="width:30%" src=<?php echo $p->getImage(); ?> alt="">
                                <div class="hover-contents">
                                    <a href="" class="hover-image">
                                    </a>
                                    <div class="hover-btns">
                                        <a href="#" class="single-btn"
                                           onclick="getSomething(<?php echo $p->getId(); ?>)">
                                            <i class="fas fa-dumpster"></i>
                                        </a>
                                        <a href="#editPrixModal" data-toggle="modal" data-target="#editPrixModal"
                                           data-id="<?php echo $p->getId(); ?>" class="open-editPrixModal single-btn">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="price-block">
                                <?php
                                echo $p->getPrix();
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        }
        }
        ?>

        <!-- The Modal -->
        <div class="modal" id="editPrixModal">
            <div class="modal-dialog">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Modifier le prix de l'oeuvre</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        Modifier le prix du livre
                        <form>
                            <label for="id">Id de l'oeuvre</label>
                            <input type="text" id="id" name="id" class="form-control" placeholder="Id"
                                   value="" required autofocus disabled>

                            <label for="id">Prix</label>
                            <input type="text" id="prix" name="prix" class="form-control" placeholder="Prix"
                                   required autofocus>
                            <br>
                            <button type="button" class="btn btn-success"
                                    onclick="modifySomething(getElementById('id').value, getElementById('prix').value)">
                                Valider
                            </button>
                        </form>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>

                </div>
            </div>
        </div>

    </div>
</section>

