<!-- Header principal -->
<header class="masthead" id="CONTACT">
    <div class="container h-100">
        <div class="row h-100 align-items-center justify-content-center text-center">
            <div class="col-lg-10 align-self-end">
                <h1 class="text-uppercase text-white font-weight-bold">Textbook</h1>
                <hr class="divider my-4">
            </div>
            <div class="col-lg-5 align-self-baseline">
                <p class="text-white-75 font-weight-light mb-5 ">Nous vous proposons donc une liste de livres, classés par catégories, pour vous aider à cheminer vos besoin pour vos etudes, lecture ou besoin de tout autre nature.</p>
                <li><img src="https://img.icons8.com/ios/50/000000/literature.png" height="100"></li>
            </div>
        </div>
    </div>
</header>

<section class="page-section bg-dark" id="Nos objectifs">
    <div class="container ">
        <h2 class=" text-center text-white text-uppercase font-weight-bold my-0">Objectifs <img src="https://img.icons8.com/wired/64/000000/group-of-projects.png"></h2>
        <hr class = "divider my-1" >
        <li style="text-decoration: underline;" and class=" text-white list-unstyled-item list-hours-item d-flex my-4"> Contribuer à la diffusion de produits.</li>
        <li style="text-decoration: underline;" and class=" text-white list-unstyled-item list-hours-item d-flex my-4"> Soutenir l’accessibilité physique à un prix raisonnable.</li>
        <li style="text-decoration: underline;" and class=" text-white list-unstyled-item list-hours-item d-flex my-4"> Permettre l’accessibilité a un vaste resau biblique.</li>
        <li style="text-decoration: underline;" and class=" text-white list-unstyled-item list-hours-item d-flex"> Promouvoir la lecture.</li>

    </div>
</section>

<section class="page-section">
    <div class="container">
        <div class="row">
            <div class="col-xl-9 mx-auto">
                <div class="cta-inner text-center rounded">

                    <h2 class=" text-center text-uppercase font-weight-bold mt-0"> Contact <img src="https://img.icons8.com/ios/50/000000/ringer-volume-filled.png"></h2>
                    <hr class = "divider" >
                    <p class ="font-weight-bold">Nous vous invitons à nous écrire pour nous faire part de vos commentaires et de vos suggestions ou nous contacter durant les heures suivantes grace au numero ci joint: </p>
                    <ul class="list-unstyled list-hours mb-5 text-left mx-auto">
                        <li class="list-unstyled-item list-hours-item d-flex">
                            Sunday
                            <span class="ml-auto">Closed</span>
                        </li>
                        <li class="list-unstyled-item list-hours-item d-flex">
                            Monday
                            <span class="ml-auto">7:00 AM to 8:00 PM</span>
                        </li>
                        <li class="list-unstyled-item list-hours-item d-flex">
                            Tuesday
                            <span class="ml-auto">7:00 AM to 8:00 PM</span>
                        </li>
                        <li class="list-unstyled-item list-hours-item d-flex">
                            Wednesday
                            <span class="ml-auto">7:00 AM to 8:00 PM</span>
                        </li>
                        <li class="list-unstyled-item list-hours-item d-flex">
                            Thursday
                            <span class="ml-auto">7:00 AM to 8:00 PM</span>
                        </li>
                        <li class="list-unstyled-item list-hours-item d-flex">
                            Friday
                            <span class="ml-auto">7:00 AM to 8:00 PM</span>
                        </li>
                        <li class="list-unstyled-item list-hours-item d-flex">
                            Saturday
                            <span class="ml-auto">9:00 AM to 5:00 PM</span>
                        </li>
                    </ul>
                    <small>
                        <em> NOUS JOINDRE AU:</em>
                    </small>
                    <br>
                    (450) 585-8468
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>