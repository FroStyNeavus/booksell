<?php
/**
 * Created by PhpStorm.
 * User: Sobhi
 * Date: 6/3/19
 * Time: 4:21 AM
 */

class AjouterAjaxControleur
{
    public function execute()
    {
        if (!ISSET($_SESSION)) session_start();
        if (!ISSET($_SESSION["connected"])) {   //utilisateur non connect�.
            return new Page("login", "Mon site - login", null, null);
        } else {
            if ($_REQUEST["nom"] != "") {

                $dao = new LivresDAO();
                $data = $dao->addLivre($_REQUEST["nom"], $_REQUEST["auteur"], $_REQUEST["editeur"], $_REQUEST["matiere"], $_REQUEST["prix"], $_REQUEST["image"]);

                if ($data == true) {

                    return new Data($data, 200);
                } else {
                    return new Data($data, 500);
                }
            } else {
                return new Page("ajouter", "Mon site - Ajouter une oeuvre", null, null);

            }
        }
    }

}