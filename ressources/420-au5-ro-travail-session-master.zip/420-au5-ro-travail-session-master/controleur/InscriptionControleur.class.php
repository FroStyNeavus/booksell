<?php
require_once('./controleur/Action.interface.php');
require_once('./vues/Page.class.php');

class InscriptionControleur implements Action {
    public function execute(){
        if (!ISSET($_REQUEST["username"])){
            return new Page("inscription", "Mon site - Inscription", null, null);
        }

        $udao = new UserDAO();
        $user = $udao->addUser($_REQUEST["username"], $_REQUEST["password"], $_REQUEST["email"]);
        if ($user == null)
        {
            $_REQUEST["field_messages"]["username"] = "Verifier les informations entrer et reessayer.";
            return new Page("inscription", "Mon site - Inscription", null, null);
        }
        if (!ISSET($_SESSION)) session_start();
        $_SESSION["connected"] = $_REQUEST["username"];
        return new Page("accueil", "Mon site - Accueil", null, null);
    }
}