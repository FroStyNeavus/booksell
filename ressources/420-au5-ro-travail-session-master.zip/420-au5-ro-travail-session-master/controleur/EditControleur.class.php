<?php
/**
 * Created by PhpStorm.
 * User: ggghhjhgv
 * Date: 5/30/19
 * Time: 4:48 AM
 */

class EditControleur
{

    public function execute()
    {
        if (!ISSET($_SESSION)) session_start();
        if (!ISSET($_SESSION["connected"]))    //utilisateur non connect�.
            return new Page("login", "Mon site - login", null, null);

        $dao = new LivresDAO();
        $data = $dao->editPrixWithId($_REQUEST["id"], $_REQUEST["prix"]);

        if ($data == true) {

            return new Data($data, 200);
        } else {
            return new Data($data, 500);
        }
    }
}