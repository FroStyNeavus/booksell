<?php
require_once('./controleur/AccueilControleur.class.php');
require_once('./controleur/CatalogueControleur.class.php');
require_once('./controleur/LoginControleur.class.php');
require_once('./controleur/LogoutControleur.class.php');
require_once('./controleur/ErreurControleur.class.php');
require_once('./controleur/AProposControleur.class.php');
require_once('./controleur/ContactControleur.class.php');
require_once('./controleur/InscriptionControleur.class.php');
require_once('./controleur/RechercheControleur.class.php');
require_once('./controleur/EditControleur.class.php');
require_once('./controleur/SupprimerControleur.class.php');
require_once('./controleur/AjouterControleur.class.php');
require_once('./controleur/AjouterAjaxControleur.class.php');






class Routeur{
	public static function getAction($nomAction){

		$classe = ucfirst($nomAction) . 'Controleur';
		if (class_exists($classe)) {
			return new $classe();
		} else {
			return new ErreurControleur();
		}

	}
}
?>
