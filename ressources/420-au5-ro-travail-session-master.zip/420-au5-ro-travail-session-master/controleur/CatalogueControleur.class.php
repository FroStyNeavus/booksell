<?php
require_once('./controleur/Action.interface.php');
require_once('./vues/Page.class.php');
require_once('./modele/classes/Livre.class.php');
require_once('./modele/classes/Liste.class.php');
require_once('./modele/LivresDAO.class.php');

class CatalogueControleur implements Action {
	public function execute(){
		if (!ISSET($_SESSION)) session_start();
		if (!ISSET($_SESSION["connected"]))	//utilisateur non connect�.
			return new Page("login", "Mon site - login", null, null);

		$dao = new LivresDAO();
		$data = $dao->findAll();

        return new Page("catalogue", "Mon site - Catalogue", $data, null);
	}
}
?>