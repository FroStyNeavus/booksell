<?php

class Utilisateur {
    protected $id;
    protected $pseudo;
    protected $courriel;
    protected $mdp;


    public function __construct($n="XXX000")	//Constructeur
    {
        $this->pseudo = $n;
    }
    
    /**
     * @return string
     */
    public function getCourriel()
    {
        return $this->courriel;
    }

    /**
     * @param string $courriel
     */
    public function setCourriel($courriel)
    {
        $this->courriel = $courriel;
    }

    public function __toString()
    {
        return "User[".$this->pseudo.", ".$this->mdp."]";
    }

    public function affiche()
    {
        echo $this->__toString();
    }

    public function loadFromRecord($ligne)
    {
        $this->pseudo = $ligne["NUMID"];
        $this->mdp = $ligne["MDP"];
    }


    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getPseudo()
    {
        return $this->pseudo;
    }

    /**
     * @param mixed $pseudo
     */
    public function setPseudo($pseudo)
    {
        $this->pseudo = $pseudo;
    }

    /**
     * @return mixed
     */
    public function getMdp()
    {
        return $this->mdp;
    }

    /**
     * @param mixed $mdp
     */
    public function setMdp($mdp)
    {
        $this->mdp = $mdp;
    }
}
?>