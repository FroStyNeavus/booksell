<?php

	require_once('./modele/classes/Modele.class.php');

	class Livre extends Modele {
		protected $id;
		protected $nom;
		protected $auteur;
		protected $editeur;
		protected $matiere;
		protected $prix;
		protected $image;

        public function __construct($id, $nom, $auteur, $editeur, $matiere, $prix, $image)
        {
            $this->id = $id;
            $this->auteur = $auteur;
            $this->nom = $nom;
            $this->editeur = $editeur;
            $this->matiere = $matiere;
            $this->prix = $prix;
            $this->image = $image;
		}

		public function setId($value){
			$this->id  = $value;
		}
		public function setNom($value){
			$this->nom  = $value;
		}
		public function setAuteur($value){
			$this->auteur  = $value;
		}
		public function setEditeur($value){
			$this->editeur  = $value;
		}
		public function setMatiere($value){
			$this->matiere  = $value;
		}
		public function setPrix($value){
			$this->prix  = $value;
		}
		public function setImage($value){
			$this->image  = $value;
		}

        public function getId()
        {
			return $this->id;
		}

        public function getNom()
        {
			return $this->nom;
		}

        public function getAuteur()
        {
			return $this->auteur;
		}

        public function getEditeur()
        {
			return $this->editeur;
		}

        public function getMatiere()
        {
			return $this->matiere;
		}

        public function getPrix()
        {
			return $this->prix;
		}

        public function getImage()
        {
			return $this->image;
		}
		public function __toString(){
			return "Livre[".$this->nom.",".$this->auteur.",".$this->editeur.",".$this->matiere.",".$this->prix."]";
		}
		public function affiche(){
			echo $this->__toString();
		}
	}