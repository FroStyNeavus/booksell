<?php
	
	require_once('./modele/configs/config.php');
	include_once('./modele/classes/Liste.class.php');
    include_once('./modele/classes/Livre.class.php');


	class LivresDAO{
        public static function find($nom)
        {
            $db = Database::getInstance();

            $livre = $db->prepare("SELECT * FROM livres WHERE Nom = :x");
            $livre->execute(array(':x' => $nom));

            $result = $livre->fetch(PDO::FETCH_OBJ);

            if ($result) {
                $l = new Livre($result->Id, $result->Nom, $result->Auteur, $result->Editeur, $result->Matiere, $result->Prix, $result->Image);
                $livre->closeCursor();
                return $l;
            }
            $livre->closeCursor();
            return null;
        }


        public static function editPrixWithId($id, $prix)
        {
            $db = Database::getInstance();

            $livre = $db->prepare("UPDATE livres SET Prix = :x WHERE Id = :y");
            $livre->execute(array(':x' => $prix, ':y' => $id));
            if ($livre == true) {
                $livre->closeCursor();
                return true;
            } else {
                $livre->closeCursor();
                return false;
            }

        }

    	public static function findAll(){
    		try{
                $liste = new Liste();
                $connection = Database::getInstance();
                $req = "SELECT * FROM livres";
                $resultat = $connection->query($req);
                foreach ($resultat as $row) {
                    $l = new Livre($row['Id'], $row['Nom'], $row['Auteur'], $row['Editeur'], $row['Matiere'], $row['Prix'], $row['Image']);
                    $liste->add($l);
                }
                $resultat->closeCursor();
                $connection = null;
                return $liste;
    		} catch(PDOExeption $e){
    			print "Error!: ".$e->getMessage()."<br/>";
    			return $liste;
    		}
    	}

        public static function deleteById($id)
        {
            $db = Database::getInstance();

            $livre = $db->prepare("DELETE FROM livres WHERE Id = :y");
            $livre->execute(array(':y' => $id));
            if ($livre == true) {
                $livre->closeCursor();
                return true;
            } else {
                $livre->closeCursor();
                return false;
            }

        }

        public static function addLivre($nom, $auteur, $editeur, $matiere, $prix, $image)
        {
            $db = Database::getInstance();

            $livre = $db->prepare("INSERT INTO livres (Id, Nom, Auteur, Editeur, Matiere, Prix, Image) VALUES (NULL, :x, :y, :z, :x, :w, :v);");
            $livre->execute(array(':x' => $nom, ':y' => $auteur, ':z' => $editeur, ':x' => $matiere, ':w' => $prix, ':v' => $image));
            if ($livre == true) {
                $livre->closeCursor();
                return true;
            } else {
                $livre->closeCursor();
                return false;
            }

        }


		
	}