<?php	
	interface Config
	{	
		const URL = "localhost";
		const DB_HOST = "localhost";
		const DB_USER = "root";
		const DB_PWD = "root";
		const DB_NAME = "vente_de_livres";
	}
?>	