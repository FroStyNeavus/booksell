<?php
include_once('./modele/classes/Database.class.php');
include_once('./modele/classes/Utilisateur.class.php');

class UserDAO
{
    public static function find($username)
    {
        $db = Database::getInstance();

        $pstmt = $db->prepare("SELECT * FROM utilisateurs WHERE pseudo = :x");
        $pstmt->execute(array(':x' => $username));

        $result = $pstmt->fetch(PDO::FETCH_OBJ);
        $p = new Utilisateur();

        if ($result)
        {
            $p->setPseudo($result->Pseudo);
            $p->setMdp($result->Mdp);
            $p->setCourriel($result->Courriel);
            $pstmt->closeCursor();
            return $p;
        }
        $pstmt->closeCursor();
        return null;
    }

    public static function addUser($username, $password, $email){

        $db = Database::getInstance();

        $pstmt = $db->prepare("INSERT INTO utilisateurs (Pseudo, Courriel, Mdp) VALUES (:x, :y, :z)");
        $result  = $pstmt->execute(array(':x' => $username, ':y' => $email, ':z' => $password));
        $p = new Utilisateur();
        if ($result)
        {
            $p->setPseudo($username);
            $p->setMdp($password);
            $p->setCourriel($email);
            $pstmt->closeCursor();
            return $p;
        }
        $pstmt->closeCursor();
        return null;
    }
}
?>