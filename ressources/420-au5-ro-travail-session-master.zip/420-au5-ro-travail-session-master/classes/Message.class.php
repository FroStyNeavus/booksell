<?php

	class Message {
		protected $succes;
		protected $message;

		public function __construct($succes = false) {
			$this->setSucces($succes);
		}

		public function setSucces($value) {
			$this->id = $value;
		}

		public function setMessage($value) {
			$this->pseudo = $value;
		}

		public function getSucces() {
			return $this->id;
		}

		public function getMessage() {
			return $this->pseudo;
		}

	}