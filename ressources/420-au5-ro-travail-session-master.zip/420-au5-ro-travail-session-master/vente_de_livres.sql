-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Mer 10 Avril 2019 à 16:03
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `vente_de_livres`
--

-- --------------------------------------------------------

--
-- Structure de la table `livres`
--

CREATE TABLE `livres` (
  `Id` int(11) NOT NULL,
  `Nom` varchar(70) DEFAULT NULL,
  `Auteur` varchar(80) DEFAULT NULL,
  `Editeur` varchar(70) DEFAULT NULL,
  `Matiere` varchar(20) NOT NULL,
  `Prix` float NOT NULL,
  `Image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `livres`
--

INSERT INTO `livres` (`Id`, `Nom`, `Auteur`, `Editeur`, `Matiere`, `Prix`, `Image`) VALUES
(1, '1984 - Folio', 'Orwell, George', 'Folio #822, 2014', 'Francais', 16.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/0703/6822/8/9782070368228/medium_9782070368228.jpg'),
(2, 'À toi pour toujours, ta Marie-Lou', 'Tremblay, Michel', 'Actes Sud, 2007', 'Francais', 12.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7427/7124/0/9782742771240/medium_9782742771240.jpg'),
(3, 'Adversaire (L\') - Folio', 'Carrière, Emmanuel', 'Folio # 3520, Gallimard, 2001', 'Francais', 12.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/0704/1621/9/9782070416219/medium_9782070416219.jpg'),
(4, 'Albertine, en cinq temps', 'Tremblay, Michel', 'Actes Sud, 2007', 'Francais', 12.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7427/7123/3/9782742771233/medium_9782742771233.jpg'),
(5, 'Amélioration du français écrit', 'Beaudin, Karoline', 'CHENELIÈRE ÉDUCATION', 'Francais', 26.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7650/4966/1/9782765049661/medium_9782765049661.jpg'),
(6, 'Anthologie de la littérature : Du Moyen âge à 1850', 'Chénier, Jean-François', 'ERPI, 2015', 'Francais', 29.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7613/5510/0/9782761355100/medium_9782761355100.jpg'),
(7, 'Anthologie de la littérature fantastique (Grands textes)', 'Limoges, Alexandre', 'CEC', 'Francais', 15.32, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7617/7861/9/9782761778619/medium_9782761778619.jpg'),
(8, 'Anthologie de la littérature québécoise, 3e édition', 'Vaillancourt, Claude', 'Beauchemin', 'Francais', 33.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7616/6209/3/9782761662093/medium_9782761662093.jpg'),
(9, 'Anthologie litt. du Moyen Âge au XIXe siècle (3 éd.)', 'Laurin, Michel', 'Beauchemin, 3e éd. 2012', 'Francais', 38.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7616/5742/6/9782761657426/medium_9782761657426.jpg'),
(10, 'Chimie organique 1', 'Girouard Stéphane,Lapierre Danielle,Marrano Claudio', 'Chenelière, 2013', 'Chimie', 64.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7650/3356/1/9782765033561/medium_9782765033561.jpg'),
(11, 'Chimie des solutions, Une approche moléculaire, 2e édition', 'Champagne, Marielle', 'ERPI, 2016', 'Chimie', 63.95, 'https://images-na.ssl-images-amazon.com/images/I/41StQ2L13PL._SX383_BO1,204,203,200_.jpg'),
(12, 'Chimie générale- Une approche moléculaire, 2e édition', 'Tro, Nivaldo J.', 'Pearson Erpi', 'Chimie', 63.95, 'https://coopscosf.com/wp-content/uploads/2019/01/9782761394840.jpg'),
(13, 'Calcul différentiel, 2e édition', 'Brunelle, Éric et Désautels, Marc-André', 'CEC, 2016', 'Mathématiques', 63.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7617/8880/9/9782761788809/medium_9782761788809.jpg'),
(14, 'Calcul intégral, 5e édition', 'Charron, Gilles et Parent, Pierre', 'Chenelière, 5e éd. 2015', 'Mathématiques', 64.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7650/4748/3/9782765047483/medium_9782765047483.jpg'),
(15, 'Mathématiques discrètes', 'Rosen, Kenneth H.', 'Chenelière', 'Mathématiques', 129.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/8946/1642/0/9782894616420/medium_9782894616420.jpg'),
(16, 'Mise à niveau mathématiques. 2e édition', 'hamel, Josée', 'Erpi sciences', 'Mathématiques', 63.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7613/7560/3/9782761375603/medium_9782761375603.jpg'),
(17, 'Notions de statistiques, 3e édition', 'Simard, Christiane', 'Modulo, 3e éd., 2015', 'Mathématiques', 66.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/8973/2017/1/9782897320171/medium_9782897320171.jpg'),
(18, 'Modèles mathématiques informatique, 2e edition', 'Ross, André', 'Prodafor inc', 'Mathématiques', 63, 'https://www.zone.coop/fileadmin/images/produits/617424_big.jpg'),
(19, 'Discours sur l\'origine et les fondements de l\'inégalité parm', 'Marsolais, Patricia', 'CEC', 'Philosophie', 11.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7617/2525/5/9782761725255/medium_9782761725255.jpg'),
(20, 'Philosophie: Les grandes questions', 'Monnier, Anne-Emmanuelle', 'Les bagages culture', 'Philosophie', 29.95, 'https://images-na.ssl-images-amazon.com/images/I/51RoQ8gfHjL._SX258_BO1,204,203,200_.jpg'),
(21, 'Les grandes questions de la philosophie de l\'Antiquité à nos jours.', 'Marie-Reine Morville', 'Delagrave', 'Philosophie', 36.95, 'https://products-images.di-static.com/image/marie-reine-morville-les-grandes-questions-de-la-philosophie-de-l-antiquite-a-nos-jours/9782206083841-200x303-1.jpg'),
(22, 'La peste Albert Camus', 'Albert Camus', 'Folio', 'Philosophie', 9.95, 'https://images-na.ssl-images-amazon.com/images/I/41ap0wZmkFL._SX302_BO1,204,203,200_.jpg'),
(23, 'Physique Vol.1., Mécanique', 'Benson, Harris', 'ERPI, 5e, éd., 2015', 'Physique', 63.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7613/7886/4/9782761378864/medium_9782761378864.jpg'),
(24, 'Physique XX. Vol. B, Électricité et magnétisme', 'Séguin Marc,Descheneau Julie,Tardif Benjamin', 'ERPI, 2010', 'Physique', 62.95, 'http://www.cooprosemont.qc.ca/ib/000023840000/CO_IMAGESBANK_MAST1/9782/7613/3076/3/9782761330763/medium_9782761330763.jpg'),
(25, 'Physique', 'Eugene Hecht', 'Boeck', 'Physique', 134.95, 'https://images-na.ssl-images-amazon.com/images/I/414hWhnlQ2L._SX420_BO1,204,203,200_.jpg'),
(26, 'Stewart - Calcul différenciel', 'James Stewart', 'Modulo', 'Mathématique', 64.95, 'http://www.renaud-bray.com/ImagesEditeurs/PG/1356/1356313-gf.jpg'),
(27, 'Physique XXI Tome A : mécanique', ' Jule Descheneau,Marc Seguin et Benjamin Tardif', 'ERPI', 'Physique', 62.95, 'http://www.renaud-bray.com/ImagesEditeurs/PG/899/899614-gf.jpg'),
(28, 'Chimie générale, 4e édition ', 'Raymond Chang, Kenneth A. Goldsby, Azélie Arpin, Luc Papillon', 'CHENELIÈRE', 'Chimie', 51.95, 'https://www.cheneliere.ca/DATA/ITEM/8781.jpg'),
(29, 'Candide', ' Voltaire,Stéphane Maltere,Christine Girodias-Majeune', 'MAGNARD', 'Francais', 4.95, 'https://images-na.ssl-images-amazon.com/images/I/41fgs7rdA8L._SX359_BO1,204,203,200_.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `Id` int(11) NOT NULL,
  `Pseudo` varchar(255) DEFAULT NULL,
  `Courriel` varchar(255) DEFAULT NULL,
  `Mdp` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `livres`
--
ALTER TABLE `livres`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `livres`
--
ALTER TABLE `livres`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
